jQuery('document').ready(function($){

    var btnmenu = $('.menu-icon');
        menu=$('.navigation ul');
        h=$('.body header');
        logo=$('#logo');
        screen=$('screen');

window.onresize = resize;

function resize()
{
    if(window.innerWidth<=650){
        h.removeClass("header1");
        h.removeClass("header2");
        h.addClass("header1");
    }
    if(window.innerWidth>=651 && window.innerWidth<=1200){
        h.removeClass("header1");
        h.removeClass("header3");
        h.addClass("header2");
    }
    if(window.innerWidth>1200){
        h.removeClass("header3");
        h.removeClass("header2");
        h.addClass("header1");
    }
}

btnmenu.click(function(){

    if(menu.hasClass('show')){
        if(window.innerWidth<=650){
            $('#menulists').slideUp(300);
            h.removeClass("header2");
            h.removeClass("header3");
            h.addClass("header1");
            logo.css('width','0px');
            logo.css('height','0px');
            logo.css('margin-top','0px');
            h.css('width','');
            menu.removeClass('show');
        }
        if(window.innerWidth<=1200 && window.innerWidth>=651){
            h.removeClass("header2");
            h.removeClass("header3");
            h.addClass("header2");
            $('#menulists').slideUp(300);
            menu.removeClass('show');
        }
    }
    else{
        
        if(window.innerWidth<=650){
            h.removeClass("header1");
            h.addClass("header2");
            logo.css('width','100px');
            logo.css('height','40px');
            logo.css('margin-top','0.3rem');
            h.css('width','203.2px');
            $('#menulists').slideDown(300);
            menu.addClass('show');
        }
        if(window.innerWidth<=1200){
            $('#menulists').slideDown(300);
            menu.addClass('show');
        }
     }
        
})
logo.click(function(){

    if(menu.hasClass('show')){
        menu.removeClass('show');
    }
    else{
        menu.addClass('show');
    }
})

$(document).ready(function(){
    if(window.innerWidth<=650){
        h.removeClass("header1");
        h.removeClass("header2");
        h.addClass("header1");
    }
    if(window.innerWidth>=651 && window.innerWidth<=1200){
        h.removeClass("header1");
        h.removeClass("header3");
        h.addClass("header2");
    }
    if(window.innerWidth>1200){
        h.removeClass("header3");
        h.removeClass("header2");
        h.addClass("header1");
    }
  });

  var altura = $(document).height();
 
  $(window).scroll(function(){
    if(window.innerWidth>=1200){
        if($(window).scrollTop()>1) {
              h.css("background-color","#000");
        }
        if($(window).scrollTop()==0) {
            h.css("background-color","transparent");
      }
    }          
  });

});