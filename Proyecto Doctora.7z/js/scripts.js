jQuery('document').ready(function($){

    var btnmenu = $('.menu-icon');
        menu=$('.navigation ul');
        h=$('.header');
        logo=$('#logo');
        screen=$('screen');

btnmenu.click(function(){

    if(menu.hasClass('show')){
        // if(h.width()==50){

        // }    
        menu.removeClass('show');

    }
    else{
            menu.addClass('show');
        
    }
})
logo.click(function(){

    if(menu.hasClass('show')){
        menu.removeClass('show');
    }
    else{
        menu.addClass('show');
    }
})



});