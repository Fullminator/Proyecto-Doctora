jQuery('document').ready(function($){

    var btnmenu = $('.menu-icon');
        menu=$('.navigation ul');
        h=$('.header');
        logo=$('#logo');
        screen=$('screen');
        h1=$('.header').prop("style");


window.onresize = resize;

function resize()
{
    if(window.innerWidth<=650){
        h1.removeProperty("left");
    }
    if(window.innerWidth>=651 && window.innerWidth<=828){
        h1.removeProperty("left");
        alert("resize event detected!");
    }
}

btnmenu.click(function(){

    if(menu.hasClass('show')){
        if(window.innerWidth<=650){
            logo.css('width','0px');
            logo.css('height','0px');
            logo.css('margin-top','0px');
            h.css('left','85%');
            h.css('width','50px');
            h.css('border-radius','30px');
            menu.removeClass('show');
        }
        if(window.innerWidth<=828 && window.innerWidth>=651){
            logo.css('width','100px');
            logo.css('height','40px');
            logo.css('margin-top','0.3rem');
            h.css('left','68%');
            h.css('width','203.2px');
            h.css('border-radius','30px');
            menu.removeClass('show');
        }
    }
    else{
        if(window.innerWidth<=650){
            logo.css('width','100px');
            logo.css('height','40px');
            logo.css('margin-top','0.3rem');
            h.css('left','55%');
            h.css('width','203.2px');
            h.css('border-radius','30px');
            menu.addClass('show');
        }
        if(window.innerWidth<=828){
            menu.addClass('show');
        }
     }
        
    
})
logo.click(function(){

    if(menu.hasClass('show')){
        menu.removeClass('show');
    }
    else{
        menu.addClass('show');
    }
})



});